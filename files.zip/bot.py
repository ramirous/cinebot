import logging
import requests
import qbittorrentapi
from telegram import Update
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    ConversationHandler, filters, ContextTypes,
)
from config import TELEGRAM_TOKEN, ALLOWED_USER_ID, QB_HOST, QB_PORT, QB_USER, QB_PASS, DOWNLOAD_PATH

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ── Estados de la conversación ────────────────────────────────────────────────
SEARCH, SELECT_MOVIE, SELECT_QUALITY, CONFIRM = range(4)

YTS_API = "https://yts.mx/api/v2/list_movies.json"

# Trackers estándar de YTS para armar magnets
YTS_TRACKERS = [
    "udp://open.demonii.com:1337/announce",
    "udp://tracker.openbittorrent.com:80",
    "udp://tracker.coppersurfer.tk:6969",
    "udp://glotorrents.pw:6969/announce",
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://torrent.gresille.org:80/announce",
    "udp://p4p.arenabg.com:1337",
    "udp://tracker.leechers-paradise.org:6969",
]


def build_magnet(info_hash: str, title: str) -> str:
    trackers = "&tr=".join(requests.utils.quote(t) for t in YTS_TRACKERS)
    return f"magnet:?xt=urn:btih:{info_hash}&dn={requests.utils.quote(title)}&tr={trackers}"


def guard(user_id: int) -> bool:
    return user_id == ALLOWED_USER_ID


# ── Helpers de presentación ───────────────────────────────────────────────────

async def _present_qualities(update: Update, context: ContextTypes.DEFAULT_TYPE, movie: dict) -> int:
    torrents = movie.get("torrents") or []
    if not torrents:
        await update.message.reply_text("❌ Sin torrents disponibles para esta película.")
        return SEARCH

    context.user_data["selected_movie"] = movie
    context.user_data["torrents"] = torrents

    lines = []
    for i, t in enumerate(torrents):
        quality = t.get("quality", "?")
        ttype   = t.get("type", "")
        size    = t.get("size", "?")
        seeds   = t.get("seeds", 0)
        lines.append(f"{i+1}. {quality} {ttype} — {size}  🌱{seeds}")

    text = (
        f"🎞 *{movie['title']} ({movie['year']})*\n\n"
        "*Calidades disponibles:*\n\n"
        + "\n".join(lines)
        + "\n\nResponde con el *número* de la calidad deseada."
    )
    await update.message.reply_text(text, parse_mode="Markdown")
    return SELECT_QUALITY


# ── Handlers ──────────────────────────────────────────────────────────────────

async def search_movie(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not guard(update.effective_user.id):
        return ConversationHandler.END

    query = update.message.text.strip()
    await update.message.reply_text(f"🔍 Buscando *{query}*…", parse_mode="Markdown")

    try:
        resp = requests.get(YTS_API, params={"query_term": query, "limit": 10}, timeout=10)
        data = resp.json()
    except Exception as e:
        await update.message.reply_text(f"❌ Error al consultar YTS: {e}")
        return SEARCH

    if data.get("status") != "ok" or data["data"]["movie_count"] == 0:
        await update.message.reply_text("❌ Sin resultados. Intenta con otro título.")
        return SEARCH

    movies = data["data"]["movies"]
    context.user_data["movies"] = movies

    if len(movies) == 1:
        return await _present_qualities(update, context, movies[0])

    lines = [f"{i+1}. {m['title']} ({m['year']})" for i, m in enumerate(movies)]
    text = (
        "🎬 *Películas encontradas:*\n\n"
        + "\n".join(lines)
        + "\n\nResponde con el *número* de la película."
    )
    await update.message.reply_text(text, parse_mode="Markdown")
    return SELECT_MOVIE


async def select_movie(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not guard(update.effective_user.id):
        return ConversationHandler.END

    try:
        idx    = int(update.message.text.strip()) - 1
        movies = context.user_data["movies"]
        if not (0 <= idx < len(movies)):
            raise ValueError
    except (ValueError, KeyError):
        await update.message.reply_text("⚠️ Opción inválida. Manda el número de la lista.")
        return SELECT_MOVIE

    return await _present_qualities(update, context, movies[idx])


async def select_quality(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not guard(update.effective_user.id):
        return ConversationHandler.END

    try:
        idx      = int(update.message.text.strip()) - 1
        torrents = context.user_data["torrents"]
        if not (0 <= idx < len(torrents)):
            raise ValueError
    except (ValueError, KeyError):
        await update.message.reply_text("⚠️ Opción inválida. Manda el número de la calidad.")
        return SELECT_QUALITY

    torrent = torrents[idx]
    context.user_data["selected_torrent"] = torrent
    movie   = context.user_data["selected_movie"]

    text = (
        "✅ *Confirmar descarga*\n\n"
        f"🎬 {movie['title']} ({movie['year']})\n"
        f"📺 {torrent.get('quality','')} {torrent.get('type','')}\n"
        f"💾 {torrent.get('size','?')}\n"
        f"📁 `{DOWNLOAD_PATH}`\n\n"
        "¿Confirmas? Responde *sí* o *no*."
    )
    await update.message.reply_text(text, parse_mode="Markdown")
    return CONFIRM


async def confirm_download(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not guard(update.effective_user.id):
        return ConversationHandler.END

    answer = update.message.text.strip().lower()
    if answer not in ("sí", "si", "s", "yes", "y"):
        await update.message.reply_text("❌ Descarga cancelada. Manda otro título cuando quieras.")
        context.user_data.clear()
        return SEARCH

    torrent = context.user_data["selected_torrent"]
    movie   = context.user_data["selected_movie"]
    magnet  = build_magnet(torrent["hash"], movie["title"])

    try:
        qbt = qbittorrentapi.Client(
            host=QB_HOST, port=QB_PORT,
            username=QB_USER, password=QB_PASS,
        )
        qbt.auth_log_in()
        qbt.torrents_add(urls=magnet, save_path=DOWNLOAD_PATH)
        await update.message.reply_text(
            f"🚀 *¡Descarga iniciada!*\n\n"
            f"🎬 {movie['title']} ({movie['year']})\n"
            f"📺 {torrent.get('quality','')} {torrent.get('type','')}\n"
            f"📁 `{DOWNLOAD_PATH}`",
            parse_mode="Markdown"
        )
    except Exception as e:
        await update.message.reply_text(f"❌ Error con qBittorrent: {e}")

    context.user_data.clear()
    return SEARCH


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.clear()
    await update.message.reply_text("Operación cancelada. Manda un título cuando quieras.")
    return SEARCH


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    app = Application.builder().token(TELEGRAM_TOKEN).build()

    conv = ConversationHandler(
        entry_points=[MessageHandler(filters.TEXT & ~filters.COMMAND, search_movie)],
        states={
            SEARCH:         [MessageHandler(filters.TEXT & ~filters.COMMAND, search_movie)],
            SELECT_MOVIE:   [MessageHandler(filters.TEXT & ~filters.COMMAND, select_movie)],
            SELECT_QUALITY: [MessageHandler(filters.TEXT & ~filters.COMMAND, select_quality)],
            CONFIRM:        [MessageHandler(filters.TEXT & ~filters.COMMAND, confirm_download)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True,
    )
    app.add_handler(conv)

    logger.info("Bot iniciado. Esperando mensajes…")
    app.run_polling()


if __name__ == "__main__":
    main()
