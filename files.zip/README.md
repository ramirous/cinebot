# Instalación y puesta en marcha

## 1. Copiar archivos al servidor

```bash
sudo mkdir -p /opt/cine_bot
sudo cp bot.py config.py requirements.txt /opt/cine_bot/
```

## 2. Crear entorno virtual e instalar dependencias

```bash
cd /opt/cine_bot
python3 -m venv venv
venv/bin/pip install -r requirements.txt
```

## 3. Habilitar qBittorrent Web UI

En qBittorrent: Herramientas → Preferencias → Web UI → Activar.
Puerto por defecto: 8080. Usuario/pass ya configurados en config.py.

## 4. Probar manualmente

```bash
cd /opt/cine_bot
venv/bin/python bot.py
```

Abre Telegram, escríbele al bot el nombre de una película. Si todo responde, parar con Ctrl+C y continuar al paso 5.

## 5. Instalar como servicio (systemd) — para que corra siempre

```bash
sudo cp cine_bot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable cine_bot
sudo systemctl start cine_bot
```

Ver logs en vivo:
```bash
journalctl -u cine_bot -f
```

## Uso

- Escríbele al bot en Telegram el **nombre de una película**
- Si hay varios resultados → responde con el número
- Elige la calidad → responde con el número
- Confirma con **sí**
- La descarga aparece en qBittorrent y va a `/mnt/DatosF/PelículasF`
- `/cancel` en cualquier momento para abortar
